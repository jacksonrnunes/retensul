<?php namespace TCK\Odbc;

use Illuminate\Database\Query\Grammars\Grammar;

class ODBCQueryGrammar extends Grammar {


}