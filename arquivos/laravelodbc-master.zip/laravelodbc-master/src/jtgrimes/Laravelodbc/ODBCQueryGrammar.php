<?php namespace jtgrimes\Laravelodbc;

use Illuminate\Database\Query\Grammars\Grammar;

class ODBCQueryGrammar extends Grammar {



}